class personajes:
    def __init__(self, Nombre, Apellido, Edad, Clase, Pechera, Guantes, Pantalones, Botas, Casco, Arma1, Arma2, NivelMagia, Hechizo1, Hechizo2, Hechizo3, Hechizo4, PV, PM, PA, PD):
        self.Nombre = Nombre
        self.Apellido = Apellido
        self.Edad = Edad
        self.Clase = Clase
        self.Pechera = Pechera
        self.Guantes = Guantes
        self.Pantalones = Pantalones
        self.Botas = Botas
        self.Casco = Casco
        self.Arma1 = Arma1
        self.Arma2 = Arma2
        self.NivelMagia = NivelMagia
        self.Hechizo1 = Hechizo1
        self.Hechizo2 = Hechizo2
        self.Hechizo3 = Hechizo3
        self.Hechizo4 = Hechizo4
        self.PV = PV
        self.PM = PM
        self.PA = PA
        self.PD = PD
    def saludar(Self):
        print(f"Hola!! {Self.Nombre}, Te espera una aventura tan grande en este mundo inexplorado")

personaje1 = personajes("Chrome", "Langley", 20, "Espadachin", "Nivel3", "Nivel3", "Nivel1", "Nivel2", "Nivel3", "Espada Carmesi", "Escudo Esmeralda", "Nivel2", "Escarcha", "Explosion", "Aurora", "Mejorar", 30, 40, 70, 60)
Dic1 = {"Nombre:", personaje1.Nombre, "Apellido:", personaje1.Apellido, "Edad:" ,personaje1.Edad, personaje1.Clase, personaje1.Pechera, personaje1.Guantes, personaje1.Pantalones, personaje1.Botas, personaje1.Casco, personaje1.Arma1, personaje1.Arma2, personaje1.NivelMagia, personaje1.Hechizo1, personaje1.Hechizo2, personaje1.Hechizo2, personaje1.Hechizo3, personaje1.Hechizo4, personaje1.PV, personaje1.PM, personaje1.PA, personaje1.PD}
personaje1.saludar()