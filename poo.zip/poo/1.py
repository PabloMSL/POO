class Persona:
    def __init__(self, nombre, apellido, edad):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad

persona1 = Persona("Ivan", "Malaver", 47)
persona2 = Persona("Hector", "Ruiz", 54)
print(persona1.nombre, persona1.apellido, persona1.edad)
print(persona2.nombre, persona2.apellido, persona2.edad)
persona1.nombre = "Jesus"
print(persona1.nombre)